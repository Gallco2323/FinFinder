﻿namespace FinFinder.Services.Data
{
    public class Class1
    {

    }
}
